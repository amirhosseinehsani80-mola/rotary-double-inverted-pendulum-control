%% Advanced Control Take Home Exam_ Amirhossein Ehsani_810602159
clc
clear all
close all
%% System
% Define symbolic variables
syms q alpha gamma dq d_alpha d_gamma ddq dd_alpha dd_gamma r l1 L1 l2 m1 m2 J_m B1 B2 g real
syms tau

% Pendulum parameters values
r = 0.2159; l1 = 0.1635; L1 = 0.2;  l2 = 0.1778; m1 = 0.097;  m2 = 0.127;  J_m = 0.0041;  B1 = 0.0024; B2 = 0.0024; g = 9.81;

% Positions of the centers of mass
x0 = r * cos(q);
y0 = r * sin(q);

x1 = r * cos(q) + l1 * cos(q + alpha);
y1 = r * sin(q) + l1 * sin(q + alpha);

x2 = r * cos(q) + L1 * cos(q + alpha) + l2 * cos(q + alpha + gamma);
y2 = r * sin(q) + L1 * sin(q + alpha) + l2 * sin(q + alpha + gamma);

% Velocities of the centers of mass
dx1 = diff(x1, q) * dq + diff(x1, alpha) * d_alpha;
dy1 = diff(y1, q) * dq + diff(y1, alpha) * d_alpha;

dx2 = diff(x2, q) * dq + diff(x2, alpha) * d_alpha + diff(x2, gamma) * d_gamma;
dy2 = diff(y2, q) * dq + diff(y2, alpha) * d_alpha + diff(y2, gamma) * d_gamma;

% Kinetic energies
T_arm = 0.5 * J_m * dq^2;
T1 = 0.5 * m1 * (dx1^2 + dy1^2) + 0.5 * B1 * d_alpha^2;
T2 = 0.5 * m2 * (dx2^2 + dy2^2) + 0.5 * B2 * d_gamma^2;

% Total kinetic energy
T = T_arm + T1 + T2;

% Potential energies
V1 = m1 * g * (r * sin(q) + l1 * sin(q + alpha));
V2 = m2 * g * (r * sin(q) + L1 * sin(q + alpha) + l2 * sin(q + alpha + gamma));

% Total potential energy
V = V1 + V2;

% Lagrangian
L = T - V;

% Euler-Lagrange equations
% Generalized coordinates: [q, alpha, gamma]
% Generalized velocities: [dq, d_alpha, d_gamma]
% Generalized accelerations: [ddq, dd_alpha, dd_gamma]

% Equation for q
dL_dq = diff(L, q);
dL_ddq = diff(L, dq);
d_dt_dL_ddq = diff(dL_ddq, q) * dq + diff(dL_ddq, alpha) * d_alpha + diff(dL_ddq, gamma) * d_gamma + diff(dL_ddq, dq) * ddq + diff(dL_ddq, d_alpha) * dd_alpha + diff(dL_ddq, d_gamma) * dd_gamma;
eq_q = d_dt_dL_ddq - dL_dq - tau;

% Equation for alpha
dL_dalpha = diff(L, alpha);
dL_ddalpha = diff(L, d_alpha);
d_dt_dL_ddalpha = diff(dL_ddalpha, q) * dq + diff(dL_ddalpha, alpha) * d_alpha + diff(dL_ddalpha, gamma) * d_gamma + diff(dL_ddalpha, dq) * ddq + diff(dL_ddalpha, d_alpha) * dd_alpha + diff(dL_ddalpha, d_gamma) * dd_gamma;
eq_alpha = d_dt_dL_ddalpha - dL_dalpha;

% Equation for gamma
dL_dgamma = diff(L, gamma);
dL_ddgamma = diff(L, d_gamma);
d_dt_dL_ddgamma = diff(dL_ddgamma, q) * dq + diff(dL_ddgamma, alpha) * d_alpha + diff(dL_ddgamma, gamma) * d_gamma + diff(dL_ddgamma, dq) * ddq + diff(dL_ddgamma, d_alpha) * dd_alpha + diff(dL_ddgamma, d_gamma) * dd_gamma;
eq_gamma = d_dt_dL_ddgamma - dL_dgamma;

% Display the equations
eq_q = simplify(eq_q);
eq_alpha = simplify(eq_alpha);
eq_gamma = simplify(eq_gamma);

%% Linearization

% Define symbolic variables for small perturbations
syms q_eq alpha_eq gamma_eq dq_eq d_alpha_eq d_gamma_eq real


% Substitute the equilibrium values into the equations
eq_q_linear = subs(eq_q, {q, alpha, gamma, dq, d_alpha, d_gamma}, {q_eq, alpha_eq, gamma_eq, dq_eq, d_alpha_eq, d_gamma_eq});
eq_alpha_linear = subs(eq_alpha, {q, alpha, gamma, dq, d_alpha, d_gamma}, {q_eq, alpha_eq, gamma_eq, dq_eq, d_alpha_eq, d_gamma_eq});
eq_gamma_linear = subs(eq_gamma, {q, alpha, gamma, dq, d_alpha, d_gamma}, {q_eq, alpha_eq, gamma_eq, dq_eq, d_alpha_eq, d_gamma_eq});

% Linearize by taking the Taylor series expansion around the equilibrium point
% and keeping only the linear terms
linear_eq_q = taylor(eq_q_linear, [q_eq, alpha_eq, gamma_eq, dq_eq, d_alpha_eq, d_gamma_eq], 'Order', 2);
linear_eq_alpha = taylor(eq_alpha_linear, [q_eq, alpha_eq, gamma_eq, dq_eq, d_alpha_eq, d_gamma_eq], 'Order', 2);
linear_eq_gamma = taylor(eq_gamma_linear, [q_eq, alpha_eq, gamma_eq, dq_eq, d_alpha_eq, d_gamma_eq], 'Order', 2);

% Simplify the linearized equations
linear_eq_q = simplify(linear_eq_q);
linear_eq_alpha = simplify(linear_eq_alpha);
linear_eq_gamma = simplify(linear_eq_gamma);

%% State space

% System Parameters
J_T = 1; Mp1 = 0.097; Mp2 = 0.127; lp1 =0.1635; lp2 = 0.1778; Lp1 = 0.2; Lp2 = 0.3365; Mh = 0.1410; Lr = 0.2159; g = 9.81; Jr = 0.0041;

% Matrix values
a42 = Lr*g*(Mp1^2*lp1^2+2*Mp1*lp1*Mh*Lp1*Mh*Lp1^2*Mp2*Mp1*lp1^2*Mp2*Mh^2*Lp1^2);
a52 = g*(Lr^2*Lp1*Mp1*Mp2+Lp1*Lr^2*Mh*Mp2+Lp1*Lr^2*Mh^2+Lr^2*Lp1&Mp1^2+Jr*Lp1*Mh+Jr*Lp1*Mp1+Lp1*Lr^2*Mh*Mp1+Lr^2*Lp1*Mh*Mp1);
a62 = -g/Lp2*(Lp1*Lr^2*Lp1*Mp1^2+Lp1*Lr^2*Lp2*Mh*Mp1+Lr^2*Lp1*Lp2*Mh*Mp1+Lp1*Lr^2*Lp2*Mh^2+Lr^2*Lp1*Lp2*Mp1^2-Mp1*Lp1^2*Lr^2*Lp1^2*Mp2+Lr^2*Lp1*Lp2*Mp1*Mp2+Lp1*Lr^2*Lp2*Mh*Mp2+Jr*Lp1*Lp2*Mh+Jr*Lp1*Lp2*Mp1-Mp1*Lp1^2*Jr+Lp1*Jr*Lp1*Mp1-Mp1*Lp1^2*Mh*Lr^2+Lr^2*Lp1*Mp2*Mp1*Lp1+Mp1*Lp1*Lr^2*Mh*Lp1-Lr^2*Mp1^2*Lp1^2);
a63 =  g/Lp2*(Jr*Lp1*Lp2*Mp2+Jr*Lp1^2*Mp2+Lp1^2*Lr^2*Mp1*Mp2+Mp1*Lp1^2*Lr^2*Mp2+Lp1*Lr^2*Lp2*Mp1*Mp2-Lr^2*Lp1*Lp2*Mp1*Mp2+Mp1*Lp1^2*Jr+Mh*Lp1^2*Jr+Mh*Lp1^2*Mp1*Lr^2+Mp1*Lp1^2*Mh*Lr^2-2*Lr^2*Lp1*Mp2*Mp1*Lp1-2*Mp1*Lp1*Lr^2*Mh*Lp1);

% State Space Matrices
A = 1/J_T*[
            0 0 0 1 0 0;
            0 0 0 0 1 0;
            0 0 0 0 0 1;
            0 a42 -Mp1*lp1*Lr*Mp2*g*(-lp1+Lp1) 0 0 0;
            0 a52 -Mp2*g*(-Lr^2*Lp1*Mp1+Lp1*Lr^2*Mp1+Jr*Lp1) 0 0 0;
            0 a62 a63 0 0 0
];

B = 1/J_T*[
            0 0;0 0;0 0;
            Mh*Lp1^2+Mp1*Lp1^2 -42.1899;
            Lr*(Mh*Lp1+Mp1*Lp1) -18.1845;
            -Lr/Lp2*(-Mp1*Lp1^2+Mp1*Lp1*Lp2+Mh*Lp1*Lp2+Mp1*Lp1^2) -12.5912
];

C = eye(6); % Identity matrix for full state vector output
D = zeros(6, 2);

%% Checking Stability

% Checking Stability with eigenvalues of the matrix A
eigenvalues = eig(A);

% Checking Stability with Lyapunov theorem
%N = lyap(A,-eye(6))
%% Controllability and Observability

Ctrb = ctrb(A,B); % if this matrix is fullrank the system is controllable
rank(Ctrb);

O = obsv(A,C); % if this matrix is fullrank the system is observable
rank(obsv(A,C)); 
%% State feedback controller

% Slow Poles 
p = [-0.000001 -30 -4 -5 -6 -7];
k_slow = place(A,B,p);

% Fast Poles
p = [-10 -30 -40 -15 0 -7];
k_fast = place(A,B,p);

% Initial Conditons
InC = [0.2 0.2 0.2 0.1 0.1 0.1];

%% Tracking Problem

% Augmented State-Space Matrices
A_aug = [A, zeros(size(A,1), 1); -C(1,:), 0];
B_aug = [B; 0 0];
C_aug = eye(7);
D_aug = zeros(7, 2);
% Desired augmented poles (including integrator pole)
aug_poles = [-0.001 -20 -5 -8 -11 -14 -17];
aug_poless = [-0.008 -21 -5 -7 -12 -13.5 -16.5];
ka = 100;

% State feedback gain with integrator
K_aug = place(A_aug, B_aug, aug_poles);
%% Observer Design

L = [place(A_aug',C_aug',aug_poles)]'*65;
L_reduce = L(1:3,1:3)*1000;

%% Reduced Order Observer Design

% Partition the state-space matrices
A11 = A_aug(1:3, 1:3);
A12 = A_aug(1:3, 4:end);
A21 = A_aug(4:end, 1:3);
A22 = A_aug(4:end, 4:end);

B1 = B_aug(1:3, :);
B2 = B_aug(4:end, :);

C1 = C_aug(1:3, :);
C2 = C_aug(4:end, :);

C_reduced = eye(3);

% Desired poles for the reduced-order observer
obs_poles = [-20 -30 -40];

% Compute the observer gain for the reduced-order observer
L_reduced = place(A11', A21', obs_poles')';

%% Uncomment this and run this section in order to run Sine Tracking and Step Tracking (Part 11 of the exam) there are few little changes in the gains
% %% State space
% 
% % System Parameters
% J_T = 1; Mp1 = 0.097; Mp2 = 0.127; lp1 =0.1635; lp2 = 0.1778; Lp1 = 0.2; Lp2 = 0.3365; Mh = 0.1410; Lr = 0.2159; g = 9.81; Jr = 0.0041;
% 
% % Matrix values
% a42 = Lr*g*(Mp1^2*lp1^2+2*Mp1*lp1*Mh*Lp1*Mh*Lp1^2*Mp2*Mp1*lp1^2*Mp2*Mh^2*Lp1^2);
% a52 = g*(Lr^2*Lp1*Mp1*Mp2+Lp1*Lr^2*Mh*Mp2+Lp1*Lr^2*Mh^2+Lr^2*Lp1&Mp1^2+Jr*Lp1*Mh+Jr*Lp1*Mp1+Lp1*Lr^2*Mh*Mp1+Lr^2*Lp1*Mh*Mp1);
% a62 = -g/Lp2*(Lp1*Lr^2*Lp1*Mp1^2+Lp1*Lr^2*Lp2*Mh*Mp1+Lr^2*Lp1*Lp2*Mh*Mp1+Lp1*Lr^2*Lp2*Mh^2+Lr^2*Lp1*Lp2*Mp1^2-Mp1*Lp1^2*Lr^2*Lp1^2*Mp2+Lr^2*Lp1*Lp2*Mp1*Mp2+Lp1*Lr^2*Lp2*Mh*Mp2+Jr*Lp1*Lp2*Mh+Jr*Lp1*Lp2*Mp1-Mp1*Lp1^2*Jr+Lp1*Jr*Lp1*Mp1-Mp1*Lp1^2*Mh*Lr^2+Lr^2*Lp1*Mp2*Mp1*Lp1+Mp1*Lp1*Lr^2*Mh*Lp1-Lr^2*Mp1^2*Lp1^2);
% a63 =  g/Lp2*(Jr*Lp1*Lp2*Mp2+Jr*Lp1^2*Mp2+Lp1^2*Lr^2*Mp1*Mp2+Mp1*Lp1^2*Lr^2*Mp2+Lp1*Lr^2*Lp2*Mp1*Mp2-Lr^2*Lp1*Lp2*Mp1*Mp2+Mp1*Lp1^2*Jr+Mh*Lp1^2*Jr+Mh*Lp1^2*Mp1*Lr^2+Mp1*Lp1^2*Mh*Lr^2-2*Lr^2*Lp1*Mp2*Mp1*Lp1-2*Mp1*Lp1*Lr^2*Mh*Lp1);
% 
% % State Space Matrices
% A = 1/J_T*[
%             0 0 0 1 0 0;
%             0 0 0 0 1 0;
%             0 0 0 0 0 1;
%             0 a42 -Mp1*lp1*Lr*Mp2*g*(-lp1+Lp1) 0 0 0;
%             0 a52 -Mp2*g*(-Lr^2*Lp1*Mp1+Lp1*Lr^2*Mp1+Jr*Lp1) 0 0 0;
%             0 a62 a63 0 0 0
% ];
% 
% B = 1/J_T*[
%             0 0 0;0 0 0;0 0 0;
%             Mh*Lp1^2+Mp1*Lp1^2 -42.1899 -32.24;
%             Lr*(Mh*Lp1+Mp1*Lp1) -18.1845 12.421;
%             -Lr/Lp2*(-Mp1*Lp1^2+Mp1*Lp1*Lp2+Mh*Lp1*Lp2+Mp1*Lp1^2) -12.5912 -16.211
% ];
% 
% C = eye(6); % Identity matrix for full state vector output
% D = zeros(6, 3);
% 
% %% Checking Stability
% 
% % Checking Stability with eigenvalues of the matrix A
% eigenvalues = eig(A);
% 
% % Checking Stability with Lyapunov theorem
% %N = lyap(A,-eye(6))
% %% Controllability and Observability
% 
% Ctrb = ctrb(A,B); % if this matrix is fullrank the system is controllable
% rank(Ctrb);
% 
% O = obsv(A,C); % if this matrix is fullrank the system is observable
% rank(obsv(A,C)); 
% %% State feedback controller
% 
% % Slow Poles 
% p = [-0.000001 -30 -4 -5 -6 -7];
% k_slow = place(A,B,p);
% 
% % Fast Poles
% p = [-10 -30 -40 -15 0 -7];
% k_fast = place(A,B,p);
% 
% % Initial Conditons
% InC = [0.2 0.2 0.2 0.1 0.1 0.1];
% 
% %% Tracking Problem
% 
% % Augmented State-Space Matrices
% A_aug = [A, zeros(size(A,1), 1); -C(1,:), 0];
% B_aug = [B; 0 0 0];
% C_aug = eye(7);
% D_aug = zeros(7, 3);
% % Desired augmented poles (including integrator pole)
% aug_poles = [-0.001 -20 -5 -8 -11 -14 -17];
% aug_poless = [-0.008 -21 -5 -7 -12 -13.5 -16.5];
% ka = 100;
% 
% % State feedback gain with integrator
% K_aug = place(A_aug, B_aug, aug_poles);
% %% Observer Design
% 
% L = [place(A_aug',C_aug',aug_poles)]'*65;
% L_reduce = L(1:3,1:3)*1000;
% 
% %% Reduced Order Observer Design
% 
% % Partition the state-space matrices
% A11 = A_aug(1:3, 1:3);
% A12 = A_aug(1:3, 4:end);
% A21 = A_aug(4:end, 1:3);
% A22 = A_aug(4:end, 4:end);
% 
% B1 = B_aug(1:3, :);
% B2 = B_aug(4:end, :);
% 
% C1 = C_aug(1:3, :);
% C2 = C_aug(4:end, :);
% 
% C_reduced = eye(3);
% 
% % Desired poles for the reduced-order observer
% obs_poles = [-20 -30 -40];
% 
% % Compute the observer gain for the reduced-order observer
% L_reduced = place(A11', A21', obs_poles')';
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
